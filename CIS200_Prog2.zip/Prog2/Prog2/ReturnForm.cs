﻿// Grading ID: T5584
// Program 2
// Due 3/8
// CIS 200-01
// This form is used return books

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class ReturnForm : Form
    {   
        private List<LibraryItem> _items; // List of library items
    
        public int ItemIndex
        {
            // Precondition:  None
            // Postcondition: The item index is returned
            get { return itemReturnComboBox.SelectedIndex; }

            // Precondition:  None
            // Postcondition: The item index is set to the specified value
            set { itemReturnComboBox.SelectedIndex = value; }
        }

        // Precondition:  None
        // Postcondition: The form is initialized 
        public ReturnForm(List<LibraryItem> items)
        {
            _items = items;
            InitializeComponent();

            foreach(LibraryItem i in _items)
            {
                itemReturnComboBox.Items.Add(i.Title + ", " + i.CallNumber);
            }
        }

        // Precondition:  The cancel button has been clicked
        // Postcondition: The form will close out
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }

        // Precondition:  The return button was clicked
        // Postcondition: The book is returned and the checked out items list will reflect that
        private void returnBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
