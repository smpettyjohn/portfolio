﻿namespace LibraryItems
{
    partial class BookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.titleLbl = new System.Windows.Forms.Label();
            this.publisherLbl = new System.Windows.Forms.Label();
            this.copyrightLbl = new System.Windows.Forms.Label();
            this.loanPeriodLbl = new System.Windows.Forms.Label();
            this.callNumberLbl = new System.Windows.Forms.Label();
            this.authorLbl = new System.Windows.Forms.Label();
            this.bookTitleTxtBox = new System.Windows.Forms.TextBox();
            this.bookPublishTxtBox = new System.Windows.Forms.TextBox();
            this.bookCopyrightTxtBox = new System.Windows.Forms.TextBox();
            this.bookLoanTxtBox = new System.Windows.Forms.TextBox();
            this.bookCallNumTxtBox = new System.Windows.Forms.TextBox();
            this.bookAuthorTxtBox = new System.Windows.Forms.TextBox();
            this.bookBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.errorProviderCopyright = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderLoan = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderTitle = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderCallNum = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCopyright)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderLoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderTitle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCallNum)).BeginInit();
            this.SuspendLayout();
            // 
            // titleLbl
            // 
            this.titleLbl.AutoSize = true;
            this.titleLbl.Location = new System.Drawing.Point(55, 35);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(42, 20);
            this.titleLbl.TabIndex = 0;
            this.titleLbl.Text = "Title:";
            // 
            // publisherLbl
            // 
            this.publisherLbl.AutoSize = true;
            this.publisherLbl.Location = new System.Drawing.Point(55, 75);
            this.publisherLbl.Name = "publisherLbl";
            this.publisherLbl.Size = new System.Drawing.Size(78, 20);
            this.publisherLbl.TabIndex = 1;
            this.publisherLbl.Text = "Publisher:";
            // 
            // copyrightLbl
            // 
            this.copyrightLbl.AutoSize = true;
            this.copyrightLbl.Location = new System.Drawing.Point(55, 115);
            this.copyrightLbl.Name = "copyrightLbl";
            this.copyrightLbl.Size = new System.Drawing.Size(118, 20);
            this.copyrightLbl.TabIndex = 2;
            this.copyrightLbl.Text = "Copyright Year:";
            // 
            // loanPeriodLbl
            // 
            this.loanPeriodLbl.AutoSize = true;
            this.loanPeriodLbl.Location = new System.Drawing.Point(55, 155);
            this.loanPeriodLbl.Name = "loanPeriodLbl";
            this.loanPeriodLbl.Size = new System.Drawing.Size(98, 20);
            this.loanPeriodLbl.TabIndex = 3;
            this.loanPeriodLbl.Text = "Loan Period:";
            // 
            // callNumberLbl
            // 
            this.callNumberLbl.AutoSize = true;
            this.callNumberLbl.Location = new System.Drawing.Point(55, 195);
            this.callNumberLbl.Name = "callNumberLbl";
            this.callNumberLbl.Size = new System.Drawing.Size(99, 20);
            this.callNumberLbl.TabIndex = 4;
            this.callNumberLbl.Text = "Call Number:";
            // 
            // authorLbl
            // 
            this.authorLbl.AutoSize = true;
            this.authorLbl.Location = new System.Drawing.Point(55, 235);
            this.authorLbl.Name = "authorLbl";
            this.authorLbl.Size = new System.Drawing.Size(61, 20);
            this.authorLbl.TabIndex = 5;
            this.authorLbl.Text = "Author:";
            // 
            // bookTitleTxtBox
            // 
            this.bookTitleTxtBox.Location = new System.Drawing.Point(185, 32);
            this.bookTitleTxtBox.Name = "bookTitleTxtBox";
            this.bookTitleTxtBox.Size = new System.Drawing.Size(141, 26);
            this.bookTitleTxtBox.TabIndex = 6;
            this.bookTitleTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookTitleTxtBox_Validating);
            this.bookTitleTxtBox.Validated += new System.EventHandler(this.bookTitleTxtBox_Validated);
            // 
            // bookPublishTxtBox
            // 
            this.bookPublishTxtBox.Location = new System.Drawing.Point(185, 72);
            this.bookPublishTxtBox.Name = "bookPublishTxtBox";
            this.bookPublishTxtBox.Size = new System.Drawing.Size(141, 26);
            this.bookPublishTxtBox.TabIndex = 7;
            // 
            // bookCopyrightTxtBox
            // 
            this.bookCopyrightTxtBox.Location = new System.Drawing.Point(185, 112);
            this.bookCopyrightTxtBox.Name = "bookCopyrightTxtBox";
            this.bookCopyrightTxtBox.Size = new System.Drawing.Size(141, 26);
            this.bookCopyrightTxtBox.TabIndex = 8;
            this.bookCopyrightTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookCopyrightTxtBox_Validating);
            this.bookCopyrightTxtBox.Validated += new System.EventHandler(this.bookCopyrightTxtBox_Validated);
            // 
            // bookLoanTxtBox
            // 
            this.bookLoanTxtBox.Location = new System.Drawing.Point(185, 152);
            this.bookLoanTxtBox.Name = "bookLoanTxtBox";
            this.bookLoanTxtBox.Size = new System.Drawing.Size(141, 26);
            this.bookLoanTxtBox.TabIndex = 9;
            this.bookLoanTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookLoanTxtBox_Validating);
            this.bookLoanTxtBox.Validated += new System.EventHandler(this.bookLoanTxtBox_Validated);
            // 
            // bookCallNumTxtBox
            // 
            this.bookCallNumTxtBox.Location = new System.Drawing.Point(185, 192);
            this.bookCallNumTxtBox.Name = "bookCallNumTxtBox";
            this.bookCallNumTxtBox.Size = new System.Drawing.Size(141, 26);
            this.bookCallNumTxtBox.TabIndex = 10;
            this.bookCallNumTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.bookCallNumTxtBox_Validating);
            this.bookCallNumTxtBox.Validated += new System.EventHandler(this.bookCallNumTxtBox_Validated);
            // 
            // bookAuthorTxtBox
            // 
            this.bookAuthorTxtBox.Location = new System.Drawing.Point(185, 232);
            this.bookAuthorTxtBox.Name = "bookAuthorTxtBox";
            this.bookAuthorTxtBox.Size = new System.Drawing.Size(141, 26);
            this.bookAuthorTxtBox.TabIndex = 11;
            // 
            // bookBtn
            // 
            this.bookBtn.AutoSize = true;
            this.bookBtn.Location = new System.Drawing.Point(98, 286);
            this.bookBtn.Name = "bookBtn";
            this.bookBtn.Size = new System.Drawing.Size(89, 30);
            this.bookBtn.TabIndex = 12;
            this.bookBtn.Text = "Add Book";
            this.bookBtn.UseVisualStyleBackColor = true;
            this.bookBtn.Click += new System.EventHandler(this.bookBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.AutoSize = true;
            this.cancelBtn.Location = new System.Drawing.Point(208, 286);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 30);
            this.cancelBtn.TabIndex = 13;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // errorProviderCopyright
            // 
            this.errorProviderCopyright.ContainerControl = this;
            // 
            // errorProviderLoan
            // 
            this.errorProviderLoan.ContainerControl = this;
            // 
            // errorProviderTitle
            // 
            this.errorProviderTitle.ContainerControl = this;
            // 
            // errorProviderCallNum
            // 
            this.errorProviderCallNum.ContainerControl = this;
            // 
            // BookForm
            // 
            this.AcceptButton = this.bookBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 345);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.bookBtn);
            this.Controls.Add(this.bookAuthorTxtBox);
            this.Controls.Add(this.bookCallNumTxtBox);
            this.Controls.Add(this.bookLoanTxtBox);
            this.Controls.Add(this.bookCopyrightTxtBox);
            this.Controls.Add(this.bookPublishTxtBox);
            this.Controls.Add(this.bookTitleTxtBox);
            this.Controls.Add(this.authorLbl);
            this.Controls.Add(this.callNumberLbl);
            this.Controls.Add(this.loanPeriodLbl);
            this.Controls.Add(this.copyrightLbl);
            this.Controls.Add(this.publisherLbl);
            this.Controls.Add(this.titleLbl);
            this.Name = "BookForm";
            this.Text = "BookForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCopyright)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderLoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderTitle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderCallNum)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Label publisherLbl;
        private System.Windows.Forms.Label copyrightLbl;
        private System.Windows.Forms.Label loanPeriodLbl;
        private System.Windows.Forms.Label callNumberLbl;
        private System.Windows.Forms.Label authorLbl;
        private System.Windows.Forms.TextBox bookTitleTxtBox;
        private System.Windows.Forms.TextBox bookPublishTxtBox;
        private System.Windows.Forms.TextBox bookCopyrightTxtBox;
        private System.Windows.Forms.TextBox bookLoanTxtBox;
        private System.Windows.Forms.TextBox bookCallNumTxtBox;
        private System.Windows.Forms.TextBox bookAuthorTxtBox;
        private System.Windows.Forms.Button bookBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ErrorProvider errorProviderCopyright;
        private System.Windows.Forms.ErrorProvider errorProviderLoan;
        private System.Windows.Forms.ErrorProvider errorProviderTitle;
        private System.Windows.Forms.ErrorProvider errorProviderCallNum;
    }
}