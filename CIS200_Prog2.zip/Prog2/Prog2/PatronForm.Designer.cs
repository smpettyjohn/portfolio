﻿namespace LibraryItems
{
    partial class PatronForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.patronIDLbl = new System.Windows.Forms.Label();
            this.patronNameLbl = new System.Windows.Forms.Label();
            this.patronNameTxtBox = new System.Windows.Forms.TextBox();
            this.patronIDTxtBox = new System.Windows.Forms.TextBox();
            this.patronBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.errorProviderName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderID = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderID)).BeginInit();
            this.SuspendLayout();
            // 
            // patronIDLbl
            // 
            this.patronIDLbl.AutoSize = true;
            this.patronIDLbl.Location = new System.Drawing.Point(28, 83);
            this.patronIDLbl.Name = "patronIDLbl";
            this.patronIDLbl.Size = new System.Drawing.Size(81, 20);
            this.patronIDLbl.TabIndex = 0;
            this.patronIDLbl.Text = "Patron ID:";
            // 
            // patronNameLbl
            // 
            this.patronNameLbl.AutoSize = true;
            this.patronNameLbl.Location = new System.Drawing.Point(28, 39);
            this.patronNameLbl.Name = "patronNameLbl";
            this.patronNameLbl.Size = new System.Drawing.Size(106, 20);
            this.patronNameLbl.TabIndex = 1;
            this.patronNameLbl.Text = "Patron Name:";
            // 
            // patronNameTxtBox
            // 
            this.patronNameTxtBox.Location = new System.Drawing.Point(146, 36);
            this.patronNameTxtBox.Name = "patronNameTxtBox";
            this.patronNameTxtBox.Size = new System.Drawing.Size(100, 26);
            this.patronNameTxtBox.TabIndex = 2;
            this.patronNameTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.patronNameTxtBox_Validating);
            this.patronNameTxtBox.Validated += new System.EventHandler(this.patronNameTxtBox_Validated);
            // 
            // patronIDTxtBox
            // 
            this.patronIDTxtBox.Location = new System.Drawing.Point(146, 80);
            this.patronIDTxtBox.Name = "patronIDTxtBox";
            this.patronIDTxtBox.Size = new System.Drawing.Size(100, 26);
            this.patronIDTxtBox.TabIndex = 3;
            this.patronIDTxtBox.Validating += new System.ComponentModel.CancelEventHandler(this.patronIDTxtBox_Validating);
            this.patronIDTxtBox.Validated += new System.EventHandler(this.patronIDTxtBox_Validated);
            // 
            // patronBtn
            // 
            this.patronBtn.AutoSize = true;
            this.patronBtn.Location = new System.Drawing.Point(38, 142);
            this.patronBtn.Name = "patronBtn";
            this.patronBtn.Size = new System.Drawing.Size(99, 30);
            this.patronBtn.TabIndex = 4;
            this.patronBtn.Text = "Add Patron";
            this.patronBtn.UseVisualStyleBackColor = true;
            this.patronBtn.Click += new System.EventHandler(this.patronBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.AutoSize = true;
            this.cancelBtn.Location = new System.Drawing.Point(161, 142);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(75, 30);
            this.cancelBtn.TabIndex = 5;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelBtn_MouseDown);
            // 
            // errorProviderName
            // 
            this.errorProviderName.ContainerControl = this;
            // 
            // errorProviderID
            // 
            this.errorProviderID.ContainerControl = this;
            // 
            // PatronForm
            // 
            this.AcceptButton = this.patronBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 213);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.patronBtn);
            this.Controls.Add(this.patronIDTxtBox);
            this.Controls.Add(this.patronNameTxtBox);
            this.Controls.Add(this.patronNameLbl);
            this.Controls.Add(this.patronIDLbl);
            this.Name = "PatronForm";
            this.Text = "PatronForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label patronIDLbl;
        private System.Windows.Forms.Label patronNameLbl;
        private System.Windows.Forms.TextBox patronNameTxtBox;
        private System.Windows.Forms.TextBox patronIDTxtBox;
        private System.Windows.Forms.Button patronBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.ErrorProvider errorProviderName;
        private System.Windows.Forms.ErrorProvider errorProviderID;
    }
}