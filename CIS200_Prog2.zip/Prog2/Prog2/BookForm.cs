﻿// Grading ID: T5584
// Program 2
// Due 3/8
// CIS 200-01
// This form is used to insert books

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class BookForm : Form
    {
        // Precondition:  None
        // Postcondition: The book form is inintialized
        public BookForm()
        {
            InitializeComponent();
        }

        internal string Publisher
        {
            // Precondition:  None
            // Postcondition: The publisher has been returned
            get
            { return bookPublishTxtBox.Text; }

            // Precondition:  None
            // Postcondition: The publisher has been set to the specified value
            set
            {
                // Since empty publisher is OK, just change null to empty string
                bookPublishTxtBox.Text = (value == null ? string.Empty : value.Trim());
            }
        }

        internal string CopyrightYear
        {
            // Precondition:  None
            // Postcondition: The copyright year has been returned
            get { return bookCopyrightTxtBox.Text; }

            // Precondition:  None
            // Postcondition: The copyright year has been set to the specified value
            set { bookCopyrightTxtBox.Text = value; }
        }

        // Precondition:  bookCopyrightTxtBox_Validating succeeded
        // Postcondition: Any error message set for bookCopyrightTxtBox is cleared
        //                Focus is allowed to change
        private void bookCopyrightTxtBox_Validated(object sender, EventArgs e)
        {
            errorProviderCopyright.SetError(bookCopyrightTxtBox, "");
        }

        // Precondition:  bookCopyrightTxtBox_Validate failed
        // Postcondition: an error message will show prompting user to enter a valid entry
        //                and won't let the user advance in the form
        private void bookCopyrightTxtBox_Validating(object sender, CancelEventArgs e)
        {
            int number;

            if (!int.TryParse(bookCopyrightTxtBox.Text, out number))
            {
                e.Cancel = true;

                errorProviderCopyright.SetError(bookCopyrightTxtBox, "Enter an integer!");

                bookCopyrightTxtBox.SelectAll();
            }
            else
            {
                if (number < 0)
                {
                    e.Cancel = true;

                    errorProviderCopyright.SetError(bookCopyrightTxtBox, "Enter a non-negative integer!");

                    bookCopyrightTxtBox.SelectAll();
                }
            }
        }


        internal string LoanPeriod
        {
            // Precondition:  None
            // Postcondition: The copyright year has been returned
            get { return bookLoanTxtBox.Text; }

            // Precondition:  None
            // Postcondition: The copyright year has been set to the specified value
            set { bookLoanTxtBox.Text = value; }
        }

        // Precondition:  bookLoanTxtBox_Validating succeeded
        // Postcondition: Any error message set for bookLoanTxtBox is cleared
        //                Focus is allowed to change
        private void bookLoanTxtBox_Validated(object sender, EventArgs e)
        {
            errorProviderLoan.SetError(bookLoanTxtBox, ""); // Clears error message

        }

        // Precondition:  bookLoanTxtBox_Validate failed
        // Postcondition: an error message will show prompting user to enter a valid entry
        //                and won't let the user advance in the form
        private void bookLoanTxtBox_Validating(object sender, CancelEventArgs e)
        {
            int number;

            if (!int.TryParse(bookLoanTxtBox.Text, out number))
            {
                e.Cancel = true;

                errorProviderLoan.SetError(bookLoanTxtBox, "Enter an integer!");

                bookLoanTxtBox.SelectAll();
            }
            else
            {
                if (number < 0)
                {
                    e.Cancel = true;

                    errorProviderLoan.SetError(bookLoanTxtBox, "Enter a non-negative integer!");

                    bookLoanTxtBox.SelectAll();
                }
            }
        }

        

        internal string CallNumber
        {
            // Precondition:  None
            // Postcondition: The call number has been returned
            get
            { return bookCallNumTxtBox.Text;  }

            // Precondition:  None
            // Postcondition: The call number has been set to the specified value
            set
            { bookCallNumTxtBox.Text = value.Trim(); }
        }

        // Precondition:  bookCallNumTxtBox_Validating succeeded
        // Postcondition: Any error message set for bookCallNumtTxtBox is cleared
        //                Focus is allowed to change
        private void bookCallNumTxtBox_Validated(object sender, EventArgs e)
        {
            errorProviderCallNum.SetError(bookCallNumTxtBox, "");
        }

        // Precondition:  bookCallNumTxtBox_Validate failed
        // Postcondition: an error message will show prompting user to enter a valid entry
        //                and won't let the user advance in the form
        private void bookCallNumTxtBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(bookCallNumTxtBox.Text))
            {
                e.Cancel = true;

                errorProviderCallNum.SetError(bookCallNumTxtBox, "Enter an call number!");

                bookCallNumTxtBox.SelectAll();
            }
        }

        internal string Title
        {
            // Precondition:  None
            // Postcondition: The title has been returned
            get { return bookTitleTxtBox.Text; }

            // Precondition:  None
            // Postcondition: The title has been set to the specified value
            set
            { bookTitleTxtBox.Text = value.Trim(); }
        }

        // Precondition:  bookTitleTxtBox_Validating succeeded
        // Postcondition: Any error message set for bookTitleTxtBox is cleared
        //                Focus is allowed to change
        private void bookTitleTxtBox_Validated(object sender, EventArgs e)
        {
            errorProviderTitle.SetError(bookTitleTxtBox, "");
        }

        // Precondition:  bookTitleTxtBox_Validate failed
        // Postcondition: an error message will show prompting user to enter a valid entry
        //                and won't let the user advance in the form
        private void bookTitleTxtBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(bookTitleTxtBox.Text))
            {
                e.Cancel = true;

                errorProviderTitle.SetError(bookTitleTxtBox, "Enter a title!");

                bookTitleTxtBox.SelectAll();
            }
        }

        internal string Author
        {
            // Precondition:  None
            // Postcondition: The author has been returned
            get { return bookAuthorTxtBox.Text; }

            // Precondition:  None
            // Postcondition: The author has been set to the specified value
            set
            {
                // Since empty publisher is OK, just change null to empty string
                bookAuthorTxtBox.Text = (value == null ? string.Empty : value.Trim());
            }
        }
        
        // Precondition:  The cancel button has been clicked
        // Postcondition: The form will close out
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }

        // Precondition:  Insert book button has been clicked
        // Postcondition: A dialog box will show prompting the user to enter
        //                book information. This will show in the itmes report
        private void bookBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
    }
}
