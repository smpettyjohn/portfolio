﻿// Grading ID: T5584
// Program 2
// Due 3/8
// CIS 200-01
// This form is used to check out books

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class CheckOutForm : Form
    {
        private List<LibraryItem> _items;  // list of library items
        private List<LibraryPatron> _patrons;   // list of patrons

        // Precondition:  None
        // Postcondition: The form is initialized
        public CheckOutForm(List<LibraryItem> items, List<LibraryPatron> patrons)
        {
            _items = items;
            _patrons = patrons;
            InitializeComponent();

            // Populates combo box with library items
            foreach (LibraryItem i in _items)
            {
                itemComboBox.Items.Add(i.Title + ", " + i.CallNumber);
            }

            // Populates combo box with patrons
            foreach (LibraryPatron p in _patrons)
            {
                patronComboBox.Items.Add(p.PatronID + ", " + p.PatronName);
            }
        }

        public int PatronIndex
        {
            // Precondition:  Nonee
            // Postcondition: The patron index is returned
            get { return patronComboBox.SelectedIndex; }
            
            // Precondition:  None
            // Postcondition: The patron index is set to the specified value
            set { patronComboBox.SelectedIndex = value; }
        }

        public int ItemIndex
        {
            // Precondition:  None
            // Postcondition: The item index is returned
            get { return itemComboBox.SelectedIndex; }

            // Precondition:  None
            // Postcondition: The item index is set to the specified value
            set { itemComboBox.SelectedIndex = value; }
        }
        
        // Precondition:  The check out button was clicked
        // Postcondition: The book will be checked out by the specified patron. The
        //                checked out items report will show this. 
        private void checkOutBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        // Precondition:  The cancel button was clicked
        // Postcondition: The form will close out.
        private void cancelBtn_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }
    }
}
