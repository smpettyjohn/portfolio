﻿// Grading ID: T5584
// Program 2
// Due 3/8
// CIS 200-01
// This form is used add patrons

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class PatronForm : Form
    {
        // Precondition:  None
        // Postcondition: The patron form is inintialized
        public PatronForm()
        {
            InitializeComponent();
        }

        internal string PatronID
        {
            // Precondition:  None
            // Postcondition: Text in patronIDTxtBox is returned
            get { return patronIDTxtBox.Text; }

            // Precondition:  None
            // Postcondition: Text in patronIDTxtBox is set to specified value
            set
            { patronIDTxtBox.Text = value; }
        }

        // Precondition:  patronIDTxtBox_Validating succeeded
        // Postcondition: Any error message set for bookLoanTxtBox is cleared
        //                Focus is allowed to change
        private void patronIDTxtBox_Validated(object sender, EventArgs e)
        {
            errorProviderID.SetError(patronIDTxtBox, "");
        }

        // Precondition:  patronIDTxtBox_Validate failed
        // Postcondition: an error message will show prompting user to enter a valid entry
        //                and won't let the user advance in the form
        private void patronIDTxtBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(patronIDTxtBox.Text))
            {
                e.Cancel = true;

                errorProviderID.SetError(patronIDTxtBox, "Enter a patron ID!");

                patronIDTxtBox.SelectAll();
            }
        }

        internal string PatronName
        {
            // Precondition:  None
            // Postcondition: Text in patronIDTxtBox is returned
            get { return patronNameTxtBox.Text; }

            // Precondition:  None
            // Postcondition: Text in patronIDTxtBox is set to specified value
            set
            { patronNameTxtBox.Text = value; }
        }

        // Precondition:  patronNameTxtBox_Validating succeeded
        // Postcondition: Any error message set for bookLoanTxtBox is cleared
        //                Focus is allowed to change
        private void patronNameTxtBox_Validated(object sender, EventArgs e)
        {
            errorProviderName.SetError(patronNameTxtBox, "");
        }

        // Precondition:  patronNameTxtBox_Validate failed
        // Postcondition: an error message will show prompting user to enter a valid entry
        //                and won't let the user advance in the form
        private void patronNameTxtBox_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(patronNameTxtBox.Text))
            {
                e.Cancel = true;

                errorProviderName.SetError(patronNameTxtBox, "Enter a patron name!");

                patronNameTxtBox.SelectAll();
            }
        }

        // Precondition:  Insert patron button has been clicked
        // Postcondition: A dialog box will show prompting the user to enter
        //                a patron name and ID. This will show in the patron report
        private void patronBtn_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        // Precondition:  The cancel button has been clicked
        // Postcondition: The form will close out
        private void cancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // Was it a left-click?
                this.DialogResult = DialogResult.Cancel;
        }
    }
}
