﻿// Grading ID: T5584
// Program 2
// Due 3/8
// CIS 200-01
// This form is used to allow users various options such ass add item or patron, check out and return item, and
// show a report for items, patrons, and checked out items

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class Prog2 : Form
    {
        private Library _lib;
        
        // Precondition:  None
        // Postcondition: The form's GUI is prepared for display. 
        //                A list of items are added to the library.
        public Prog2()
        {
            InitializeComponent();
            
            _lib = new Library(); // Create the library

            // Insert test data
            _lib.AddLibraryBook("C# Coding for Even Dumber Dummies", "Dumber Dummie Publishing", 
                2012, 8, "AB 8765", "Smarty Pants");
            _lib.AddLibraryBook("Taxes 101", "Snipes Inc.", 
                2010, 11, "XY 0909", "Wesley Snipes");
            _lib.AddLibraryJournal("Rocket Surgery 101", "The Rocket Surgery Co.", 
                2020, 9, "IP 2134", 2, 3, "Rocket Surgery", "Master Rocket Surgeons Guild");
            _lib.AddLibraryJournal("Journal of Nothing", "Nothing Inc.",
                1999, 2, "RE 8798", 8, 4, "Seriously Nothing", "Who Knows");
            _lib.AddLibraryMusic("September", "Columbia Records",
            2018, 12, "ZZ25 3G", 63, "Earth, Wind & Fire", LibraryMediaItem.MediaType.CD, 15);
            _lib.AddLibraryMusic("good kid, m.A.A.d city (Deluxe)", "Top Dawg Entertainment",
            2012, 6, "GH89 7G", 92, "Kendrick Lamar", LibraryMediaItem.MediaType.VINYL, 17);
            _lib.AddLibraryMovie("Kicking and Screaming", "Mosaic Media Group", 2005, 22,
            "43T7 90", 95, "Jesse Dylan", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG);
            _lib.AddLibraryMovie("The Room", "Wiseau-Films", 2003, 2,
            "LMAO 65", 99, "Tommy Wiseau", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.R);
            _lib.AddLibraryMagazine("    Sports Illustrated    ", "Authentic Brands Group", 2018,
            7, "  AE84 7A   ", 3, 11);
            _lib.AddLibraryMagazine("National Geographic", "Nat Geo Publishing", 2017,
            4, "GTXW 8O", 2, 4);

            // Add 5 patrons
            _lib.AddPatron("Wesley Snipes", "792900");
            _lib.AddPatron("The Artist Formerly Known as Prince", "654321");
            _lib.AddPatron("   John Smith   ", "   654321   ");
            _lib.AddPatron("Jane Doe", "112233");
            _lib.AddPatron("Ima Reader", "123456");
        }      

        // Precondition:  The about button has been clicked
        // Postcondition: A messagebox shows grading ID, program number, due date, and course number
        private void aboutBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Grading ID: T5584" + 
                Environment.NewLine + "Program 2" + 
                Environment.NewLine + "Due 3/8/20" + 
                Environment.NewLine + "CIS 200-01");
        }

        // Precondition:  Exit has been clicked
        // Postcondition: All forms will be closed
        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Precondition:  Insert patron has been clicked
        // Postcondition: A dialog box has been displayed prompting for the patron information. If
        //                user submits, MainForm is updated to display the patron info. The patron will 
        //                show up in the report patron list as well.
        private void patronInsertBtn_Click(object sender, EventArgs e)
        {
            PatronForm pf = new PatronForm();
            DialogResult result;
            string PatronName, PatronID;

            result = pf.ShowDialog();
            
            if(result == DialogResult.OK)
            {
                PatronName = pf.PatronName;
                PatronID = pf.PatronID;

                _lib.AddPatron(PatronName, PatronID);
            }            
        }

        // Precondition:  Insert book has been clicked
        // Postcondition: A dialog box has been displayed prompting for the book information. If
        //                user submits, MainForm is updated to display the book info. The book will 
        //                show up in the report for items list and checked out items if checked out. 
        private void bookInsertBtn_Click(object sender, EventArgs e)
        {
            BookForm bf = new BookForm();
            DialogResult result;
            int CopyrightYear, LoanPeriod;
            string Author, Publisher, CallNumber, Title;

            result = bf.ShowDialog();

            if(result == DialogResult.OK)
            {
                CopyrightYear = int.Parse(bf.CopyrightYear);
                LoanPeriod = int.Parse(bf.LoanPeriod);
                Author = bf.Author;
                Publisher = bf.Publisher;
                CallNumber = bf.CallNumber;
                Title = bf.Title;

                _lib.AddLibraryBook(Author, Publisher, CopyrightYear, LoanPeriod, CallNumber, Title);
            }
        }

        // Precondition:  Patron report has been clicked
        // Postcondition: The main form will be updated to show a list and count of patrons
        private void patronReportBtn_Click(object sender, EventArgs e)
        {
            string result = "";

            foreach (LibraryPatron p in _lib.GetPatronsList())
            {
                result += p + Environment.NewLine + Environment.NewLine;
            }

            reportTxtBox.Text = "Library patrons: " + _lib.GetPatronCount() + Environment.NewLine + 
                Environment.NewLine + result;
        }

        // Precondition:  Item report has been clicked
        // Postcondition: The main form is updated to show a list and count of items
        private void itemReportBtn_Click(object sender, EventArgs e)
        {
            string result = "";

            foreach (LibraryItem i in _lib.GetItemsList())
            {
                result += i + Environment.NewLine + Environment.NewLine;
            }

            reportTxtBox.Text = "Library Items: " + _lib.GetItemCount() + Environment.NewLine + 
                Environment.NewLine + result;
        }

        // Precondition:  Checked out item has been clicked
        // Postcondition: The main form will be updated to show a list and count of checked out items
        private void checkedOutItemsBtn_Click(object sender, EventArgs e)
        {
            string result = "";

            foreach(LibraryItem i in _lib.GetItemsList())
            {
                if (i.IsCheckedOut())
                {
                    result += i + Environment.NewLine + Environment.NewLine;
                }
            }

            reportTxtBox.Text = "Checked out items: " + _lib.GetCheckedOutCount() + Environment.NewLine + 
                Environment.NewLine + result;
        }

        // Precondition:  Check out item has been clicked
        // Postcondition: A dialog box has been displayed prompting for the book to be checked out and
        //                and by which patron. This will show up in checked out items report 
        private void checkOutItemBtn_Click(object sender, EventArgs e)
        {
            CheckOutForm cof = new CheckOutForm(_lib.GetItemsList(), _lib.GetPatronsList());
            DialogResult result;
            result = cof.ShowDialog();

            if(result == DialogResult.OK)
            {
                _lib.CheckOut(cof.ItemIndex, cof.PatronIndex);
            }
        }

        // Precondition:  Return item has been clicked
        // Postcondition: A dialog box has been displayed prompting for the book to be returned.
        //                The book will no longer show in the checked out items report 
        private void returnItemBtn_Click(object sender, EventArgs e)
        {
            ReturnForm rf = new ReturnForm(_lib.GetItemsList());
            DialogResult result;
            result = rf.ShowDialog();

            if (result == DialogResult.OK)
            {
                _lib.ReturnToShelf(rf.ItemIndex);
            }
        }
    }
}
