﻿// Grading ID:          L3564
// Program:             1
// Due Date:            9/24/19
// Course Section:      75
// Description:         This program allows a user to enter measurements and numbers from
//                      a room to figure out how much paint they will need to paint said room

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {

            double minGallonsPaint, // the minimum AMOUNT of paint needed for the room
                wallHeight,         // the height of the wall
                wallLength;         // total length of the walls

            int numWindows,         // number of windows in the room
                reqGallonsPaint,    // the minimum FULL GALLONS of paint needed for the room
                numCoats,           // how many coats of paint needed
                numDoors;           // number of doors in the room

            const int CAN_OF_PAINT_SQ_FT = 400,   // area (in sq. ft) a single can of paint covers
                      AVG_DOOR_SIZE = 21,         // area (in sq. ft) a door takes up
                      AVG_WINDOW_SIZE = 12;       // area (in sq. ft) a window takes up

            WriteLine("Welcome to the Handy-Dandy Paint Estimator");
            WriteLine("");          // empty line to create space between welcome statement and the user input section

            Write("Enter the total length of all walls (in feet): ");
            wallLength = double.Parse(ReadLine());

            Write("Enter the height of the walls (in feet): ");
            wallHeight = double.Parse(ReadLine());

            Write("Enter the number of doors (non-neg int): ");
            numDoors = int.Parse(ReadLine());

            Write("Enter the number of windows (non-neg int): ");
            numWindows = int.Parse(ReadLine());

            Write("Enter the number of coats of paint (non-neg int): ");
            numCoats = int.Parse(ReadLine());
            WriteLine("");           // empty line to create space between user input section and the output section

            minGallonsPaint = (((wallLength * wallHeight) - (numDoors * AVG_DOOR_SIZE) - (numWindows * AVG_WINDOW_SIZE)) * numCoats) / CAN_OF_PAINT_SQ_FT;  // formula for minimum amout of paint needed
            reqGallonsPaint = (int)Math.Ceiling(minGallonsPaint);                                                                                           // formula for minimum gallons of paint needed

            WriteLine($"You need a minimum of {minGallonsPaint:f1} gallons of paint");    // displays minimum amount of paint needed
            WriteLine($"You'll need to buy {reqGallonsPaint} gallons of paint, though");  // displays minimum gallons of paint needed




        }
    }
}
