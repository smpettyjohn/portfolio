﻿// Program 1A
// CIS 200-01
// Due: 2/20/2020
// By: T5584

// File: Program.cs
// This file creates a small application that tests the LibraryItem hierarchy

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LibraryItems;
using static System.Console;


public class Program
{
    // Precondition:  None
    // Postcondition: The LibraryItem hierarchy has been tested demonstrating polymorphism
    //                in CalcLateFee()
    public static void Main(string[] args)
    {
        const int DAYSLATE = 14; // Number of days late to test each object's CalcLateFee method

        // 2 instances of LibraryMusic
        LibraryMusic album1 = new LibraryMusic("September", "Columbia Records",
            2018, 12, "ZZ25 3G", 63, "Earth, Wind & Fire", LibraryMediaItem.MediaType.CD, 15);  // 1st test album
        LibraryMusic album2 = new LibraryMusic("good kid, m.A.A.d city (Deluxe)", "Top Dawg Entertainment",
            2012, 6, "GH89 7G", 92, "Kendrick Lamar", LibraryMediaItem.MediaType.VINYL, 17);     // 2nd test album

        // 2 instances of LibraryMovie
        LibraryMovie movie1 = new LibraryMovie("Kicking and Screaming", "Mosaic Media Group", 2005, 22,
            "43T7 90", 95, "Jesse Dylan", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG);  // 1st test movie
        LibraryMovie movie2 = new LibraryMovie("The Room", "Wiseau-Films", 2003, 2,
            "LMAO 65", 99, "Tommy Wiseau", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.R);                    // 2nd test movie

        // 2 instances of LibraryBook
        LibraryBook book1 = new LibraryBook("The Color Mauve", "Beautiful Books Ltd.",
            1985, 10, "JJ43 4T", "Mary Smith");   // 3rd test book
        LibraryBook book2 = new LibraryBook("The Guan Guide to SQL", "UofL Press",
            2016, 45, "ZZ24 4F", "Jeff Guan");    // 4th test book

        // 2 instances of LibraryMagazine
        LibraryMagazine magazine1 = new LibraryMagazine("    Sports Illustrated", "   Authentic Brands Group", 2018,
            7, "AE84 7A   ", 3, 11); // 5th test book - Trims?
        LibraryMagazine magazine2 = new LibraryMagazine("Sports Illustrated", "Authentic Brands Group", 2015,
            11, "AU72 7A   ", 1, 5);
        LibraryMagazine magazine3 = new LibraryMagazine("National Geographic", "Nat Geo Publishing", 2017,
            4, "GTXW 8O", 2, 4);

        // 2 instances of LibraryJournal
        LibraryJournal journal1 = new LibraryJournal("Journal of Journaling", "Journal Press", 1988, 10, "1111 AZ", 2, 17, "Physics", "Physics Weekly");
        LibraryJournal journal2 = new LibraryJournal("The Journal", "Publishing Inc.", 2001, 17, "1122 AB", 3, 7, "Journaling", "The Daily Journal");

        // Library Patrons
        LibraryPatron patron1 = new LibraryPatron("Ima Reader", "123456"); // 1st test patron
        LibraryPatron patron2 = new LibraryPatron("Jane Doe", "112233");  // 2nd test patron
        LibraryPatron patron3 = new LibraryPatron("   John Smith   ", "   654321   "); // 3rd test patron - Trims?
        LibraryPatron patron4 = new LibraryPatron("The Artist Formerly Known as Prince", "654321"); // 4th test patron
        LibraryPatron patron5 = new LibraryPatron("Wesley Snipes", "792900"); // 5th test patron

        // List of library patron
        List<LibraryPatron> patrons = new List<LibraryPatron> { patron1, patron2, patron3, patron4, patron5 };

        // List of library items
        List<LibraryItem> theItems = new List<LibraryItem> { album1, album2, movie1, movie2, book1, book2, magazine1, magazine2, magazine3, journal1, journal2 }; // Test list of items

        // Step 1: Display original list of items
        WriteLine("Original list of items");
        WriteLine("----------------------");
        foreach (LibraryItem item in theItems)
            WriteLine($"{item}\n");
        Pause();
        
        // Step 2: Check out 5 items and display again
        book1.CheckOut(patron1);
        album1.CheckOut(patron2);
        magazine1.CheckOut(patron3);
        movie2.CheckOut(patron4);
        journal2.CheckOut(patron5);
        
        WriteLine("List of items after check out");
        WriteLine("-----------------------------");
        foreach (LibraryItem item in theItems)
            WriteLine($"{item}\n");
        Pause();

        // Step 3: Display items that are checked out as well as the count of items checked out
        var checkedOut =
            from item in theItems
            where item.IsCheckedOut()
            select item;

        WriteLine("Checked out items");
        WriteLine("-----------------");

        foreach (var item in checkedOut)
        {
            WriteLine(item);
            WriteLine();
        }
        WriteLine("Number of checked out items: " + checkedOut.Count());
        Pause();

        // Step 4: Filter the results from previous step to only display checked out media items
        var checkedOutMediaItems =
            from item in checkedOut
            where item is LibraryMediaItem
            select item;

        WriteLine("Checked out media items");
        WriteLine("-----------------------");

        foreach (var item in checkedOutMediaItems)
        {
            WriteLine(item);
            WriteLine();
        }
        Pause();

        // Step 5: Display only uniqe magazine titles
        var uniqueTitles =
            from item in theItems
            where item is LibraryMagazine
            select item.Title;

        WriteLine("Unique magazine titles");
        WriteLine("----------------------");

        foreach (var item in uniqueTitles.Distinct())
        {
            WriteLine(item);
            WriteLine();
        }
        Pause();

        // Step 6: Calculate the late fee if each item were 14 days late. Display title, call number, and late fee
        WriteLine($"Calculated late fees after {DAYSLATE} days late: ");
        WriteLine("----------------------------------------------------");
        WriteLine($"{"Title",31} {"Call Number",11} {"Late Fee",8:C}");
        WriteLine("------------------------------- ----------- --------");
        
        // Wright's Way
        
            // Caluclate and display late fees for each item
            // foreach (LibraryItem item in items)
            //   WriteLine($"{item.Title,30} {item.CallNumber,11} {item.CalcLateFee(DAYSLATE),8:C}");
            // Pause();
        
        foreach (LibraryItem item in theItems)
        {
            decimal lateFee = item.CalcLateFee(14);

            WriteLine($"{item.Title,31} {item.CallNumber,11} {lateFee,8:C}");

        }
        Pause();

        // Step 7: Return all checked out items and display the count of checked out items
        book1.ReturnToShelf();
        album1.ReturnToShelf();
        magazine1.ReturnToShelf();
        movie2.ReturnToShelf();
        journal2.ReturnToShelf();

        WriteLine("Number of checked out items: " + checkedOut.Count());

        Pause();

        // Step 8: Displays each book's loan period, then add 7 days to each book's loan period and display again
        WriteLine("Current loan period for each book: ");
        WriteLine("-------------------------------------------------------");
        WriteLine($"{"Title",31} {"Call Number",11} {"Loan Period",11}");
        WriteLine("------------------------------- ----------- -----------");

        foreach (LibraryItem item in theItems)
        {
            if (item is LibraryBook)
            {
                WriteLine($"{item.Title,31} {item.CallNumber,11} {item.LoanPeriod,11}");
                WriteLine();
            }
        }
        Pause();

        // Add 7 days to each item's loan period
        WriteLine("Loan period after adding 7 Days");
        WriteLine("-------------------------------------------------------");
        WriteLine($"{"Title",31} {"Call Number",11} {"Loan Period",11}");
        WriteLine("------------------------------- ----------- -----------");

        foreach (LibraryItem item in theItems)
        {
            if (item is LibraryBook)
            {
                item.LoanPeriod += 7;
                WriteLine($"{item.Title,31} {item.CallNumber,11} {item.LoanPeriod,11}");
                WriteLine();
            }
        }
        Pause();

        // Display list of items one last time
        WriteLine("Display final list of items");
        WriteLine("---------------------------");
        foreach (LibraryItem item in theItems)
            WriteLine($"{item}\n");
        Pause();
    }

    // Precondition:  None
    // Postcondition: Pauses program execution until user presses Enter and
    //                then clears the screen
    public static void Pause()
    {
        WriteLine("Press Enter to Continue...");
        ReadLine();

        Clear(); // Clear screen
    }
}