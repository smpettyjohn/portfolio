﻿// Grading ID:      T5584
// Program:         1A
// Due Date:        2/12/20
// Course Section:  01

// Class Description: This class is a derived class from LibraryMediaItem. It contains all the relevant
//                    information that a library would have on its movies

using System;
using System.Collections.Generic;
using System.Text;

namespace Program1A
{
    public class LibraryMovie : LibraryMediaItem
    {
        public enum MPAARatings { G, PG, PG13, R, NC17, U}; // the different movie ratings
        private MPAARatings _ratings;   // movie rating backing field
        private string _director;       // the movie's director
        private MediaType _medium;      // the movie's medium
        
        // Precondition:  theCopyrightYear >= 0, theLoanPeriod >= 0, theDuration >= 0
        //                theTitle, theCallNumber, theDirector may not be null or empty
        // Postcondition: The library movie has been initialized with the specified
        //                values for title, publisher, copyright year, loan period, duration, director, medium, rating, and
        //                call number. The movie is not checked out. 
        public LibraryMovie(String theTitle, String thePublisher, int theCopyrightYear, int theLoanPeriod, 
            String theCallNumber, double theDuration, String theDirector, MediaType theMedium, MPAARatings theRating)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theDuration)
        {
            Director = theDirector;
            Medium = theMedium;
            Rating = theRating;

            ReturnToShelf();
        }

        public string Director
        {
            // Precondtion:  None
            // Postcondition: the director is returned
            get
            {
                return _director;
            }
            // Precondition:  The value must not be null or empty
            // Postcondition: The director has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Director)}", value,
                        $"{nameof(Director)} must not be null or empty");
                else
                    _director = value.Trim();
            }
        }

        public override MediaType Medium
        {
            // Precondition:  None
            // Postcondition: The medium has been returned
            get
            {
                return _medium;
            }
            // Precondition:  the value is one of the mediums
            // Postcondition: the medium has been set to the specified value
            set
            {
                if(value >= MediaType.DVD && value <= MediaType.VHS)
                    _medium = value;
                else
                    throw new ArgumentOutOfRangeException("Invalid Medium!");
            }
        }
        public MPAARatings Rating
        {
            // Precondition:  None
            // Postcondition: The rating has been returned
            get
            {
                return _ratings;
            }
            // Precondition:  the value is one of the rating types
            // Postcondition: the rating has been set to the specified value
            set
            {
                if (Enum.IsDefined(typeof(MPAARatings), value))      
                    _ratings = value;
                else
                    throw new ArgumentOutOfRangeException("Invalid Rating!");
            }
        }

        // Precondition:  daysLate >= 0
        // Postcondition: a decimal value is returned that represents the late fee
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal DVD_VHS_RATE = 1.00M; // daily late fee rate for DVDs
            const decimal BLURAY_RATE = 1.50M;  // daily late fee rate for BluRay
            const decimal MAX_FEE = 25M;        // max late fee for movies
            decimal lateFee;                    // total late fee for the movie

            // determines which late fee rate to use depending on the Medium
            if (Medium == MediaType.DVD || Medium == MediaType.VHS)
                lateFee = daysLate * DVD_VHS_RATE;
            else
                lateFee = daysLate * BLURAY_RATE;

            // determines if fee reaches the limit, returns the appropriate late fee
            if (lateFee > MAX_FEE)
                return MAX_FEE;
            else
                return lateFee;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the libary item's
        //                data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine;    // NewLine shortcut
            
            return base.ToString() + $"{NL}Director: {Director}{NL}Medium: {Medium}{NL}Rating: {Rating}";
        }
    }
}
