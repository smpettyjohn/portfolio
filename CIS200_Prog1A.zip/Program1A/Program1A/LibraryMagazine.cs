﻿// Grading ID:      T5584
// Program:         1A
// Due Date:        2/12/20
// Course Section:  01

// Class Description: This class is a derived class from LibraryPeriodical. It contains all the relevant
//                    information that a library would have on its magazines

using System;
using System.Collections.Generic;
using System.Text;

namespace Program1A
{
    public class LibraryMagazine : LibraryPeriodical
    {
        // Precondition:  theCopyrightYear >= 0, theLoanPeriod >= 0, theVolume >= 1, theNumber >= 1
        //                theTitle, theCallNumber,  may not be null or empty
        // Postcondition: The library journal has been initialized with the specified
        //                values for title, publisher, copyright year, loan period, volume, number, and
        //                call number. The journal is not checked out.
        public LibraryMagazine(String theTitle, String thePublisher, int theCopyrightYear, int theLoanPeriod,
            String theCallNumber, int theVolume, int theNumber)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {
            ReturnToShelf();
        }

        // Precondition:  daysLate >= 0
        // Postcondition: a decimal value is returned that represents the late fee
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal MAGAZINE_RATE = .25M;     // the daily late fee rate for magazines
            const decimal MAX_FEE = 20.00M;         // the max late fee for magazines
            decimal lateFee;    // the late fee

            lateFee = daysLate * MAGAZINE_RATE;

            // determines if the late fee meets the max fee, returns appropriate fee
            if (lateFee > MAX_FEE)
                return MAX_FEE;
            else
                return lateFee;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the libary item's
        //                data on separate lines
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
