﻿// Grading ID:      T5584
// Program:         1A
// Due Date:        2/12/20
// Course Section:  01

// Class Description: This class is a derived class from LibraryItem. It contains all the relevant
//                    information that a library would have on its media items. Derived classes will provide bodies for it

using System;
using System.Collections.Generic;
using System.Text;

namespace Program1A
{
    public abstract class LibraryMediaItem : LibraryItem
    {
        public enum MediaType { DVD, BLURAY, VHS, CD, SACD, VINYL };    // the different media types
        private double _duration;   // the media item's duration
        
        // Precondition:  theCopyrightYear >= 0, theLoanPeriod >= 0, theDuration >= 0
        //                theTitle, theCallNumber may not be null or empty
        // Postcondition: The library media item has been initialized with the specified
        //                values for title, author, publisher, copyright year, loan period, duration, and
        //                call number. The media item is not checked out. 
        public LibraryMediaItem(String theTitle, String thePublisher, 
            int theCopyrightYear, int theLoanPeriod, String theCallNumber, double theDuration) 
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Duration = theDuration;

            ReturnToShelf();
        }
       
        public double Duration
        {
            // Precondition:  None
            // Postcondition: the duration has been returned
            get
            {
                return _duration;
            }

            // Precondition:  value >= 0
            // Postcondition: The loan period year has been set to the specified value
            set
            {
                if (value >= 0)
                    _duration = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
                        $"{nameof(Duration)} must be >= 0");
            }
        }

        public abstract MediaType Medium
        {get; set;}

        // Precondition:  None
        // Postcondition: A string is returned representing the libary item's
        //                data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine;    // NewLine shortcut

            return base.ToString() + $"{NL}Duration: {Duration}";
        }
    }
}
