﻿// Grading ID:      T5584
// Program:         1A
// Due Date:        2/12/20
// Course Section:  01
    
// Class Description: This class is a derived class from LibraryItem. It contains all the relevant
//                    information that a library would have on its books

using System;
using System.Collections.Generic;
using System.Text;

namespace Program1A
{
    public class LibraryBook : LibraryItem
    {
        private string _author;     // The book's author

        // Precondition:  theCopyrightYear >= 0, theLoanPeriod >= 0
        //                theTitle, theCallNumber may not be null or empty
        // Postcondition: The library book has been initialized with the specified
        //                values for title, author, publisher, copyright year, loan period, and
        //                call number. The book is not checked out.
        public LibraryBook(String theTitle, String theAuthor, String thePublisher,
            int theCopyrightYear, int theLoanPeriod, String theCallNumber) 
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber)
        {
            Author = theAuthor;

            ReturnToShelf(); // Make sure book is not checked out
        }
        public string Author
        {
            // Precondition:  None
            // Postcondition: The author has been returned
            get
            {
                return _author;
            }

            // Precondition:  None
            // Postcondition: The author has been set to the specified value
            set
            {
                // Since empty author is OK, just change null to empty string
                _author = (value == null ? string.Empty : value.Trim());
            }
        }

        // Precondition:  daysLate >= 0
        // Postcondition: a decimal value is returned that represents the late fee
        public override decimal CalcLateFee(int daysLate)
        {
            decimal lateFee;    // the calculated late fee
            const decimal BOOK_RATE = 0.25M;    // the daily late fee rate for books

            lateFee = daysLate * BOOK_RATE;

            return lateFee;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the libary item's
        //                data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine;    // NewLine shortcut          

            return base.ToString() + $"{NL}Author: {Author}";
        }
    
    }
}
