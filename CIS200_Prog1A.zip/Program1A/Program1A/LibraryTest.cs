﻿// Grading ID:      T5584
// Program:         1A
// Due Date:        2/12/20
// Course Section:  01

// Class Description: This is the test program. Any actions or tasks that need to be
//                    performed happen here

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Program1A
{
    public class LibraryTest
    {

        static void Main(string[] args)
        {
            // 2 instances of LibraryMusic
            LibraryMusic album1 = new LibraryMusic("September", "Columbia Records",
                2018, 12, "ZZ25 3G", 63, "Earth, Wind & Fire", LibraryMediaItem.MediaType.CD , 15);  // 1st test album
            LibraryMusic album2 = new LibraryMusic("good kid, m.A.A.d city (Deluxe)", "Top Dawg Entertainment",
                2012, 6, "GH89 7G", 92, "Kendrick Lamar", LibraryMediaItem.MediaType.VINYL, 17);     // 2nd test album

            // 2 instances of LibraryMovie
            LibraryMovie movie1 = new LibraryMovie("Kicking and Screaming", "Mosaic Media Group" , 2005, 22,
                "43T7 90", 95, "Jesse Dylan", LibraryMediaItem.MediaType.BLURAY, LibraryMovie.MPAARatings.PG);  // 1st test movie
            LibraryMovie movie2 = new LibraryMovie("The Room", "Wiseau-Films", 2003, 2, 
                "LMAO 65", 99, "Tommy Wiseau", LibraryMediaItem.MediaType.DVD, LibraryMovie.MPAARatings.R);                    // 2nd test movie

            // 2 instances of LibraryBook
            LibraryBook book1 = new LibraryBook("The Color Mauve", "Mary Smith", "Beautiful Books Ltd.",
                1985, 10, "JJ43 4T");   // 3rd test book
            LibraryBook book2 = new LibraryBook("The Guan Guide to SQL", "Jeff Guan", "UofL Press",
                2016, 45, "ZZ24 4F");    // 4th test book
            
            // 2 instances of LibraryMagazine
            LibraryMagazine magazine1 = new LibraryMagazine("    Sports Illustrated", "   Authentic Brands Group", 2018,
                7, "AE84 7A   ", 3, 11); // 5th test book - Trims?
            LibraryMagazine magazine2 = new LibraryMagazine("Sports Illustrated", "Authentic Brands Group", 2015,
                11, "AU72 7A   ", 1, 5);
            LibraryMagazine magazine3 = new LibraryMagazine("National Geographic", "Nat Geo Publishing", 2017,
                4, "GTXW 8O", 2, 4);

            // 2 instances of LibraryJournal
            LibraryJournal journal1 = new LibraryJournal("Journal of Journaling", "Journal Press", 1988, 10, "1111 AZ", 2, 17, "Physics", "Physics Weekly");
            LibraryJournal journal2 = new LibraryJournal("The Journal", "Publishing Inc.", 2001, 17, "1122 AB", 3, 7, "Journaling", "The Daily Journal");

            // Library Patrons
            LibraryPatron patron1 = new LibraryPatron("Ima Reader", "123456"); // 1st test patron
            LibraryPatron patron2 = new LibraryPatron("Jane Doe", "112233");  // 2nd test patron
            LibraryPatron patron3 = new LibraryPatron("   John Smith   ", "   654321   "); // 3rd test patron - Trims?
            LibraryPatron patron4 = new LibraryPatron("The Artist Formerly Known as Prince", "654321"); // 4th test patron
            LibraryPatron patron5 = new LibraryPatron("Wesley Snipes", "792900"); // 5th test patron
            
            // List of library patron
            List<LibraryPatron> patrons = new List<LibraryPatron> { patron1, patron2, patron3, patron4, patron5 };
            
            // List of library items
            List<LibraryItem> theItems = new List<LibraryItem> { album1, album2, movie1, movie2, book1, book2, magazine1, magazine2, magazine3, journal1, journal2 }; // Test list of items

            // Step 1: Display original list of items
            WriteLine("Original list of items");
            WriteLine("----------------------");
            PrintBooks(theItems);
            Pause();

            // Check out 5 items and display again
            book1.CheckOut(patron1);
            album1.CheckOut(patron2);
            magazine1.CheckOut(patron3);
            movie2.CheckOut(patron4);
            journal2.CheckOut(patron5);

            WriteLine("Checked out list of items");
            WriteLine("----------------------");
            PrintBooks(theItems);
            Pause();

            // LINQ selection of items that are checked out
            // Displays resulting items and count of checkeed out items
            var checkedOut =
                from item in theItems
                where item.IsCheckedOut()
                select item; 

            WriteLine("LINQ selection list of items");
            WriteLine("----------------------");

            foreach (var item in checkedOut)
            {
                WriteLine(item);
                WriteLine();
            }
            Pause();

            // LINQ selection of only library media items that are checked out
            // Displays results to console
            var checkedOutMediaItems =
                from item in checkedOut
                where item is LibraryMediaItem
                select item;

            WriteLine("LINQ selection list of Library Media Items");
            WriteLine("----------------------");

            foreach (var item in checkedOutMediaItems)
            {
                WriteLine(item);
                WriteLine();
            }
            Pause();

            // LINQ selection of unique titles of magazines

            var uniqueTitles =
                from item in theItems
                where item is LibraryMagazine
                select new { item.Title };

            WriteLine("LINQ selection list of unique magazine titles");
            WriteLine("----------------------");

            foreach (var item in uniqueTitles)
            {
                WriteLine(item);
                WriteLine();
            }
            Pause();
        }

        // Precondition:  None
        // Postcondition: The books have been printed to the console
        public static void PrintBooks(List<LibraryItem> items)
        {
            foreach (LibraryItem i in items)
            {
                WriteLine(i);
                WriteLine();
            }
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();

            Clear(); // Clear screen
        }
    }    
}
