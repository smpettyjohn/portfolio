﻿// Grading ID:      T5584
// Program:         1A
// Due Date:        2/12/20
// Course Section:  01

// Class Description: This class is a derived class from LibraryMediaItem. It contains all the relevant
//                    information that a library would have on its music

using System;
using System.Collections.Generic;
using System.Text;

namespace Program1A
{
    class LibraryMusic : LibraryMediaItem
    {
        private MediaType _medium;  // the music's medium
        private string _artist;     // the artist of the music
        private int _numTracks;     // the number of tracks 
        
        // Precondition:  theCopyrightYear >= 0, theLoanPeriod >= 0, theDuration >= 0, theNumTracks >= 1
        //                theTitle, theCallNumber, theArtist may not be null or empty
        // Postcondition: The library music has been initialized with the specified
        //                values for title, publisher, copyright year, loan period, duration, artist, medium, number of tracks, and
        //                call number. The music is not checked out. 
        public LibraryMusic(String theTitle, String thePublisher, int theCopyrightYear, int theLoanPeriod, String theCallNumber, 
            double theDuration, String theArtist, MediaType theMedium, int theNumTracks)
            : base(theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theDuration)
        {
            Artist = theArtist;
            Medium = theMedium;
            NumTracks = theNumTracks;

            ReturnToShelf();
        }

        public string Artist
        {
            // Precondition:  None
            // Postcondition: the artist is returned 
            get
            {
                return _artist;
            }
            // Precondition:  the value must not be null or empty
            // Postcondition: the artist has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Artist)}", value,
                        $"{nameof(Artist)} must not be null or empty");
                else
                    _artist = value.Trim();
            }
        }

        public override MediaType Medium
        {
            // Precondition:  None
            // Postcondition: the medium has been returned
            get
            {
                return _medium;
            }
            // Precondition:  the value is one of the mediums
            // Postcondition: the medium has been set to the specified value
            set
            {
                if (value >= MediaType.CD && value <= MediaType.VINYL)    
                    _medium = value;
                else
                    throw new ArgumentOutOfRangeException("Invalid Medium!");
            }
        }
        public int NumTracks
        {
            // Precondition:  None
            // Postcondition: The number of tracks has been returned
            get
            {
                return _numTracks;
            }

            // Precondition:  value >= 1
            // Postcondition: The number of tracks has been set to the specified value
            set
            {
                if (value >= 1)
                    _numTracks = value;
                else
                    throw new ArgumentOutOfRangeException($"{nameof(NumTracks)}", value,
                        $"{nameof(NumTracks)} must be >= 0");
            }
        }

        // Precondition:  daysLate >= 0
        // Postcondition: a decimal value is returned that represents the late fee
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal MUSIC_RATE = .50M;
            const decimal MAX_FEE = 20.00M;
            decimal lateFee;

            lateFee = daysLate * MUSIC_RATE;

            if (lateFee > MAX_FEE)
                return MAX_FEE;
            else
                return lateFee;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the libary item's
        //                data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine;    // NewLine shortcut
            
            return base.ToString() + $"{NL}Artist: {Artist}{NL}Medium: {Medium}{NL}Number of Tracks: {NumTracks}";
        }
    }
}
