﻿// Grading ID:      T5584
// Program:         1A
// Due Date:        2/12/20
// Course Section:  01

// Class Description: This class is a derived class from LibraryPeriodical. It contains all the relevant
//                    information that a library would have on its journals

using System;
using System.Collections.Generic;
using System.Text;

namespace Program1A
{
    public class LibraryJournal : LibraryPeriodical
    {
        private string _editor;         // the journal's editor
        private string _discipline;     // the journal's discipline
        
        // Precondition:  theCopyrightYear >= 0, theLoanPeriod >= 0, theVolume >= 1, theNumber >= 1
        //                theTitle, theCallNumber, theDiscipline, theEditor may not be null or empty
        // Postcondition: The library journal has been initialized with the specified
        //                values for title, publisher, copyright year, loan period, volume, number, discipline, editor and
        //                call number. The journal is not checked out.
        public LibraryJournal(String theTitle, String thePublisher, int theCopyrightYear, int theLoanPeriod, String theCallNumber,
            int theVolume, int theNumber, String theDiscipline, String theEditor)
            : base (theTitle, thePublisher, theCopyrightYear, theLoanPeriod, theCallNumber, theVolume, theNumber)
        {
            Discipline = theDiscipline;
            Editor = theEditor;

            ReturnToShelf();
        }

        public string Editor
        {
            // Precondition:  None
            // Postcondition: The editor is returned
            get
            {
                return _editor;
            }
            // Precondition:  the value must not be null or empty
            // Postcondition: the editor is set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Editor)}", value,
                        $"{nameof(Editor)} must not be null or empty");
                else
                    _editor = value.Trim();
            }
        }
        public string Discipline
        {
            // Precondition:  None
            // Postcondition: The discipline is returned
            get
            {
                return _discipline;
            }
            // Precondition:  the value must not be null or empty
            // Postcondition: the discipline is set ot the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value)) // IsNullOrWhiteSpace includes tests for null, empty, or all whitespace
                    throw new ArgumentOutOfRangeException($"{nameof(Discipline)}", value,
                        $"{nameof(Discipline)} must not be null or empty");
                else
                    _discipline = value.Trim();
            }
        }

        // Precondition:  numDays >= 0
        // Postcondition: the late fee is returned
        public override decimal CalcLateFee(int daysLate)
        {
            const decimal JOURNAL_RATE = .75M;  // the daily late fee rate for journals
            decimal lateFee;    // the late fee

            lateFee = daysLate * JOURNAL_RATE;

            return lateFee;
        }

        // Precondition:  None
        // Postcondition: A string is returned representing the libary item's
        //                data on separate lines
        public override string ToString()
        {
            string NL = Environment.NewLine;    // NewLine shortcut
            
            return base.ToString() + $"{NL}Discipline: {Discipline}{NL}Editor: {Editor}";
        }
    }
}
