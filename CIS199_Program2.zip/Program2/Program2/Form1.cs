﻿// Grading ID:              L3564
// Program #:               2
// Due Date:                10/16/19
// Course Section:          75
// Program Description:     This program allows students to enter their last name and number of credit hours to see
//                          the earliest they are allowed to schedule classes for the Spring 2020 semester

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        // this event handler runs a test to see registration date and time after clicking the 'Run' button based on 
        // a student's last name and number of credit hours 

        private void runBtn_Click(object sender, EventArgs e)
        {
            double credHours;                           // the number of credit hours a student has
            char firstInitial;                          // the first letter of the last name entered
            string regTime,                             // the time students can register
                   regDate,                             // the date students can register
                   lastName,                            // the full last name entered into the text box
                   day1 = "Monday, Nov. 4th",           
                   day2 = "Tuesday, Nov. 5th",
                   day3 = "Wednesday, Nov. 6th",        // the days students can register depending on
                   day4 = "Thursday, Nov. 7th",         // last name and credit hours
                   day5 = "Friday, Nov. 8th",
                   day6 = "Monday, Nov. 11th",
                   time1 = "8:30am",
                   time2 = "10:00am",
                   time3 = "11:30am",                   // the times students can register depending on
                   time4 = "2:00pm",                    // last name and credit hours
                   time5 = "4:00pm";

            const double SENIOR_HRS = 90,               // the minimum hours required to hold senior status
                         JUNIOR_HRS = 60,               // the minimum hours required to hold junior status
                         SOPHOMORE_HRS = 30;            // the minimum hours required to hold sophomore status

            lastName = lastNameTxtBox.Text;             // extracts the last name a user enters
            firstInitial = lastName[0];                 // extracts the first inital from the last name

            if(char.IsLetter(firstInitial))             // tests to see if the first initial of the last name is an acceptable letter

                if(double.TryParse(creditHrsTxtBox.Text, out credHours) && (credHours > 0))     // tests to make sure the student entered acceptable credit hours
                {
                    firstInitial = char.ToUpper(firstInitial);      // turns the first inital to an uppercase letter


                    if(credHours >= JUNIOR_HRS)
                    {
                        if (firstInitial <= 'D')            // determines registration time for juniors and seniors based on last name first initial
                            regTime = time3;
                        else if (firstInitial <= 'I')
                            regTime = time4;
                        else if (firstInitial <= 'O')               
                            regTime = time5;
                        else if (firstInitial <= 'S')
                            regTime = time1;
                        else
                            regTime = time2;
                    }
                    else
                    {
                        if (firstInitial <= 'B')            // determines registration time for freshman and sophomores based on last name first initial 
                            regTime = time5;
                        else if (firstInitial <= 'D')
                            regTime = time1;
                        else if (firstInitial <= 'F')
                            regTime = time2;
                        else if (firstInitial <= 'I')
                            regTime = time3;
                        else if (firstInitial <= 'L')
                            regTime = time4;                        
                        else if (firstInitial <= 'O')
                            regTime = time5;
                        else if (firstInitial <= 'Q')
                            regTime = time1;
                        else if (firstInitial <= 'S')
                            regTime = time2;
                        else if (firstInitial <= 'V')
                            regTime = time3;
                        else
                            regTime = time4;
                    }
                    if (credHours >= SENIOR_HRS)                // determines registration day based on credit hours 
                        regDate = day1;
                    else if (credHours >= JUNIOR_HRS)       
                        regDate = day2;
                    else if ((credHours >= SOPHOMORE_HRS) && (firstInitial >= 'P' || firstInitial <= 'B'))
                        regDate = day3;
                    else if (credHours >= SOPHOMORE_HRS)
                        regDate = day4;
                    else if ((credHours < SOPHOMORE_HRS) && (firstInitial >= 'P' || firstInitial <= 'B'))
                        regDate = day5;
                    else
                        regDate = day6;

                    MessageBox.Show($"The earliest you can register is {regDate} at {regTime}");        // popup box that shows when a student can register

                }
                else
                {
                    MessageBox.Show("Enter a valid number for credit hours");       // popup box when user enters an invalid number for credit hours
                }
            else
            {
                MessageBox.Show("Enter valid characters for last name");            // popup box when user enters an invalid last name
            }

        }
    }
}
