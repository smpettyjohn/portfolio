﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lastNameLbl = new System.Windows.Forms.Label();
            this.creditHrsLbl = new System.Windows.Forms.Label();
            this.lastNameTxtBox = new System.Windows.Forms.TextBox();
            this.creditHrsTxtBox = new System.Windows.Forms.TextBox();
            this.runBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lastNameLbl
            // 
            this.lastNameLbl.AutoSize = true;
            this.lastNameLbl.Location = new System.Drawing.Point(73, 55);
            this.lastNameLbl.Name = "lastNameLbl";
            this.lastNameLbl.Size = new System.Drawing.Size(88, 20);
            this.lastNameLbl.TabIndex = 0;
            this.lastNameLbl.Text = "Last name:";
            // 
            // creditHrsLbl
            // 
            this.creditHrsLbl.AutoSize = true;
            this.creditHrsLbl.Location = new System.Drawing.Point(62, 101);
            this.creditHrsLbl.Name = "creditHrsLbl";
            this.creditHrsLbl.Size = new System.Drawing.Size(99, 20);
            this.creditHrsLbl.TabIndex = 1;
            this.creditHrsLbl.Text = "Credit hours:";
            // 
            // lastNameTxtBox
            // 
            this.lastNameTxtBox.Location = new System.Drawing.Point(167, 52);
            this.lastNameTxtBox.Name = "lastNameTxtBox";
            this.lastNameTxtBox.Size = new System.Drawing.Size(100, 26);
            this.lastNameTxtBox.TabIndex = 2;
            // 
            // creditHrsTxtBox
            // 
            this.creditHrsTxtBox.Location = new System.Drawing.Point(167, 98);
            this.creditHrsTxtBox.Name = "creditHrsTxtBox";
            this.creditHrsTxtBox.Size = new System.Drawing.Size(100, 26);
            this.creditHrsTxtBox.TabIndex = 3;
            // 
            // runBtn
            // 
            this.runBtn.AutoSize = true;
            this.runBtn.Location = new System.Drawing.Point(124, 166);
            this.runBtn.Name = "runBtn";
            this.runBtn.Size = new System.Drawing.Size(81, 30);
            this.runBtn.TabIndex = 6;
            this.runBtn.Text = "Run";
            this.runBtn.UseVisualStyleBackColor = true;
            this.runBtn.Click += new System.EventHandler(this.runBtn_Click);
            // 
            // Program2
            // 
            this.AcceptButton = this.runBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(329, 250);
            this.Controls.Add(this.runBtn);
            this.Controls.Add(this.creditHrsTxtBox);
            this.Controls.Add(this.lastNameTxtBox);
            this.Controls.Add(this.creditHrsLbl);
            this.Controls.Add(this.lastNameLbl);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lastNameLbl;
        private System.Windows.Forms.Label creditHrsLbl;
        private System.Windows.Forms.TextBox lastNameTxtBox;
        private System.Windows.Forms.TextBox creditHrsTxtBox;
        private System.Windows.Forms.Button runBtn;
    }
}

