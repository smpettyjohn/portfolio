﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


class TestLibraryBook
{
    static void Main(string[] args)
    {
        // create class objects
        LibraryBook book1 = new LibraryBook("Coding for Dummies", "Codey", "Dummy Publishing", 1872, "1234");
        LibraryBook book2 = new LibraryBook("Shredding Guitar in the Rain", "The Artist Formerly Known as Prince", "Prince Publishing", 2007, "4321");
        LibraryBook book3 = new LibraryBook("Fires for Dummies", "Caveman John", "Neanderthal Publishing", 1, "2222");
        LibraryBook book4 = new LibraryBook("Alaska", "Andrew Johnson", "President Publishing", 1867, "9876");
        LibraryBook book5 = new LibraryBook("Who Let the Dogs Out?", "Baha Men", "Dawg Publishing", 2000, "6789");
                          
        LibraryBook[] books = new LibraryBook[5];

        // initialize array
        books[0] = book1;
        books[1] = book2;
        books[2] = book3;
        books[3] = book4;
        books[4] = book5;

        DisplayBooks(books);        // displays books' info to console
        book1.Publisher = "Dummie Publishing Inc.";     // changes book info
        book2.CallNumber = "1111";                      // changes book info
        book1.CheckOut();       // checks out book
        book2.CheckOut();       // checks out book
        DisplayBooks(books);    // displays books' info to console
        book1.ReturnToShelf();  // returns book
        book2.ReturnToShelf();  // returns book
        DisplayBooks(books);    // displays books' info to console
    }

    // Precondition: None
    // Postcondition: Displays the books' info
    static void DisplayBooks(LibraryBook[] books)
    {
        // cycles through each library book and displays its info to the console
        foreach(LibraryBook libraryBooks in books)
        {
            WriteLine($"{libraryBooks}");
        }

    }
}
