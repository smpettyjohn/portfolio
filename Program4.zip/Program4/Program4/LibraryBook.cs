﻿// Grading ID:          L3564
// Program Number:      4
// Due Date:            12/3
// Course Section:      75
// Program Description: This program contains two classes that represent books held at a library
//                      and a test that displays book information and changes/checks out books

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class LibraryBook
{
    private string _title;          // book title
    private string _author;         // book author
    private string _publisher;      // book publisher
    private string _callNumber;     // book call number
    private int _copywrightYear;    // book copywright year
    bool isCheckedOut = false;      // book check out status, defaulted to false

    // Precondition: copywright >= 0
    // Postcondition: The book is constructed with the specified title, author, publisher
    //                copywright year, and call number
    public LibraryBook(string title, string author, string publisher, int copywright, string callNumber)
    {
        Title = title;
        Author = author;
        Publisher = publisher;
        CopywrightYear = copywright;
        CallNumber = callNumber;
    }

    // Precondition: None
    // Postcondition: The book's check out status is set to true
    public void CheckOut()
    {
        isCheckedOut = true;
    }

    // Precondition: None
    // Postcondition: The book's check out status is set to false
    public void ReturnToShelf()
    {
        isCheckedOut = false;
    }

    // Precondition: None
    // Postcondition: The book's check out status is returned
    public bool IsCheckedOut()
    {
        return isCheckedOut;
    }

    // Precondition: None
    // Postcondition: The library books' information is returned as a formatted string
    public override string ToString()
    {
        return $"Title: {Title}{Environment.NewLine}" +
            $"Author: {Author}{Environment.NewLine}" +
            $"Publisher: {Publisher}{Environment.NewLine}" +
            $"Copywright Year: {CopywrightYear}{Environment.NewLine}" +
            $"Call number: {CallNumber}{Environment.NewLine}" +
            $"Checked out status: {isCheckedOut}{Environment.NewLine}";
    }
    public string Title
    {
        // Precondition: None
        // Postcondition: The book's title is returned
        get { return _title; }
        
        // Precondition: None
        // Postcondition: The book's title is set to the specified value
        set { _title = value; }
    }
    public string Author
    {
        // Precondition: None
        // Postcondition: The book's author is returned
        get { return _author; }
        
        // Precondition: None
        // Postcondition: The book's author is set to the specified value
        set { _author = value; }
    }
    public string Publisher
    {
        // Precondition: None
        // Postcondition: The book's publisher is returned
        get { return _publisher; }
        
        // Precondition: None
        // Postcondition: The book's title is set to the specified value
        set { _publisher = value; }
    }
    public int CopywrightYear
    {
        // Precondition: None
        // Postcondition: The book's copywright year is returned
        get
        { return _copywrightYear; }
        
        // Precondition: value >= 0
        // Postcondition: The book's copywright year is set to the specified value
        //                or 0 if invalid
        set
        {
            if (value >= 0)     // validation
                _copywrightYear = value;
            else
                _copywrightYear = 0;   // safe default
        }
    }
    public string CallNumber
    {
        // Precondition: None
        // Postcondition: The book's call number is returned
        get { return _callNumber; }
        
        // Precondition: None
        // Postcondition: The book's call number is set to the specified value
        set { _callNumber = value; }
    }
}
