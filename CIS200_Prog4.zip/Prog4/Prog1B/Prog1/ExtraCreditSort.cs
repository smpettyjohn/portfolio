﻿// Program 4
// CIS 200-01
// Due: 4/15/20
// By: T5584

// File. TypeTitleOrder.cs
// This file uses the comparer to create a multilevel sort for the library items by item type and then by title

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class ExtraCreditSort : Comparer<LibraryItem>
    {
        // Precondition:  None
        // Postcondition: Sorts list by item type, within each item group it is sorted by Title
        //                When item1 < item2, method returns negative #
        //                When item1 == item2, method returns zero
        //                When item1 > item2, method returns positive #
        public override int Compare(LibraryItem item1, LibraryItem item2)
        {
            // Ensure correct handling of null values (in .NET, null less than anything)
            if (item1 == null && item2 == null) // Both null?
                return 0;                       // Equal

            if (item1 == null)  // only item1 is null?
                return -1;      

            if (item2 == null)  // only item2 is null?
                return 1;       

            // Different type? Uses item type to decide
            if (item1.GetType().ToString().CompareTo(item2.GetType().ToString()) != 0)
                return item1.GetType().ToString().CompareTo(item2.GetType().ToString());

            if (item1.Title.CompareTo(item2.Title) != 0)    // Different title?
                return item1.Title.CompareTo(item2.Title);  // Uses Title to decide
            else
                return 0;   // Returns 0 if same title
        }
    }
}
